

////////////////////////
//
// Welcome to UberMenu!
//
////////////////////////


http://wpmegamenu.com


All UberMenu Documentation can be found online at https://sevenspark.com/docs/ubermenu-3/

The resources are linked from within the plugin interface


===========================
QUICK START GUIDE
===========================

https://sevenspark.com/docs/ubermenu-3/quick-start



===========================
INSTALLATION INSTRUCTIONS
===========================

https://sevenspark.com/docs/ubermenu-3/install



===========================
DOCUMENTATION / SUPPORT RESOURCES
===========================

Knowledgebase		https://sevenspark.com/docs/ubermenu-3/
Video Tutorials 	https://sevenspark.com/docs/ubermenu-3/video-tutorials
Troubleshooter		https://sevenspark.com/symptom/ubermenu-symptoms
Support Center		https://sevenspark.com/help
